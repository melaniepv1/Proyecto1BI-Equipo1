# Dashboard de supermercado — version para validar en Power BI Desktop

## Abrir

1. Extrae este ZIP completo en una carpeta nueva; conserva tu PBIX original.
2. Abre `Proyecto de Power BI.pbip` con la misma version de Power BI Desktop con la que lo guardaste.
3. PostgreSQL debe estar activo. El origen conservado es `localhost:5432`, base `proyecto_bi`.
4. Pulsa **Actualizar**. Si solicita credenciales, usa las de tu PostgreSQL. El paquete no contiene una contraseña.
5. Si solicita autorizar la consulta nativa, corresponde a un SELECT de solo lectura que completa el alcance de las promociones.
6. Revisa las cinco paginas, prueba filtros y compara las cifras sin filtros con la tabla de abajo.
7. Guarda y usa **Guardar como → .pbix** si necesitas entregar un archivo unico.

Se omitio la cache de datos para que Power BI procese las columnas calculadas nuevas al actualizar. No es necesario ejecutar nuevamente Pentaho.

## Contenido

- 01 Ventas y rentabilidad: ventas, unidades, tickets, ticket promedio, ganancia, margen; tendencia mensual y detalle por producto/sucursal.
- 02 Clientes y canales: ticket y frecuencia por segmento, canal y metodo de pago.
- 03 Promociones: periodos de vigencia aplicables al producto, con comparacion de ventas por producto-dia.
- 04 Inventario: rotacion, observaciones de falta de existencias y bajo minimo.
- 05 Cobertura: dias por producto/sucursal y proporcion de pares en riesgo por categoria y sucursal.
- `Medidas_DAX.md`: formulas agregadas.
- `Validacion_PostgreSQL.sql`: consultas de solo lectura para corroborar indicadores.
- `Aporte_informe_persona5.md`: texto tecnico y hallazgos preliminares; completar con capturas y comprobacion en Desktop.

## Totales de referencia

Calculados independientemente a partir del SQL del repositorio compartido. Solo deben coincidir si la base local contiene esos mismos datos.

| Indicador | Valor sin filtros |
|---|---:|
| Lineas de venta | 17 921 |
| Tickets | 6 000 |
| Unidades | 44 984 |
| Ventas | 87 361 049,12 |
| Costo | 63 142 053,00 |
| Ganancia bruta | 24 218 996,12 |
| Ticket promedio | 14 560,17 |
| Margen bruto | 27,72 % |
| Cortes producto-sucursal | 26 500 |
| Observaciones sin stock | 194 |
| Observaciones bajo minimo (stock positivo) | 2 149 |

## Decisiones de calculo

- Los tickets usan DISTINCTCOUNT. La frecuencia se calcula entre clientes compradores en el contexto seleccionado.
- Al filtrar productos, el ticket promedio representa el importe de esos productos por ticket que los contiene, no el importe de la canasta completa.
- La rotacion es unidades vendidas del periodo / promedio de stock total por corte disponible. No se anualiza.
- El stock no se suma entre fechas. La cobertura usa el ultimo corte del periodo seleccionado y las ventas de los siete dias hasta ese corte / 7.
- La cobertura solo se muestra por un producto y una sucursal. No se suman dias de cobertura de productos distintos.
- Sin ventas recientes, la cobertura queda en blanco; el estado informa el motivo. Stock cero se marca como riesgo aun sin ventas recientes.
- Riesgo: stock cero o cobertura menor a siete dias. Es un umbral propuesto para el ejercicio, no una politica aprobada por la empresa.
- Inventario son observaciones semanales: dos semanas consecutivas sin stock no demuestran dos eventos distintos.
- P3 usa fechas y alcance de promociones, no solamente el id_promocion de la venta. Los dias producto incluyen dias sin ventas y evitan contar dos veces promociones solapadas. Con varios productos, la tasa es por producto-dia.
- Para P3 se agregaron dos atributos de alcance al modelo de Power BI mediante LEFT JOIN de `supermercado_dw.dim_promocion` con `supermercado.promocion`. Es una consulta de lectura, no modifica SQL ni Pentaho. Como mejora del DW, estos atributos deberian incorporarse a la dimension y a su ETL.
- La comparacion promocional es descriptiva: no controla estacionalidad, mezcla comercial ni otros factores; no prueba efecto causal.
- El primer corte semanal tiene menos de siete dias de historia disponible. Su cobertura puede estar sobreestimada.

## Estado de verificacion

Se revisaron estructura JSON, referencias a campos, posicion de visuales y formulas por inspeccion; los totales se recalcularon a partir del SQL. Los JSON del informe se comprobaron contra esquemas publicos de Microsoft compatibles con las propiedades utilizadas.

Este entorno no ejecuta Power BI Desktop: faltan la ejecucion DAX/M, la actualizacion contra tu PostgreSQL y la revision visual final en Desktop. Si aparece un error, comparte el texto completo o la captura. No presentar capturas ni resultados como validados en Desktop hasta realizar esa comprobacion.
