-- Ejecutar en proyecto_bi. Todas las consultas son de solo lectura.
-- 1. Totales del DW: comparar contra Power BI sin filtros.
SELECT COUNT(*) AS lineas, COUNT(DISTINCT id_venta) AS tickets,
 SUM(cantidad_vendida) AS unidades, SUM(monto_venta) AS ventas,
 SUM(costo_total) AS costo, SUM(ganancia_bruta) AS ganancia,
 SUM(monto_venta)/NULLIF(COUNT(DISTINCT id_venta),0) AS ticket_promedio,
 SUM(ganancia_bruta)/NULLIF(SUM(monto_venta),0) AS margen
FROM supermercado_dw.fact_ventas;
-- 2. Fuente: los resultados deben coincidir con los de arriba.
SELECT COUNT(*) AS lineas, COUNT(DISTINCT dv.id_venta) AS tickets,
 SUM(dv.cantidad) AS unidades, SUM(dv.cantidad*dv.precio_unitario-dv.descuento) AS ventas,
 SUM(dv.cantidad*p.costo_unitario) AS costo,
 SUM(dv.cantidad*dv.precio_unitario-dv.descuento-dv.cantidad*p.costo_unitario) AS ganancia
FROM supermercado.detalle_venta dv JOIN supermercado.producto p USING(id_producto);
-- 3. Desempeno por categoria.
SELECT p.categoria, SUM(v.monto_venta) AS ventas,SUM(v.cantidad_vendida) AS unidades,
 SUM(v.ganancia_bruta) AS ganancia
FROM supermercado_dw.fact_ventas v JOIN supermercado_dw.dim_producto p USING(sk_producto)
GROUP BY p.categoria ORDER BY ventas DESC;
-- 4. Ticket y frecuencia por segmento, canal y pago.
SELECT c.segmento, ca.nombre AS canal, mp.nombre AS pago,
 COUNT(DISTINCT v.id_venta) AS tickets, COUNT(DISTINCT v.sk_cliente) AS clientes,
 SUM(v.monto_venta)/NULLIF(COUNT(DISTINCT v.id_venta),0) AS ticket_promedio,
 COUNT(DISTINCT v.id_venta)::numeric/NULLIF(COUNT(DISTINCT v.sk_cliente),0) AS frecuencia
FROM supermercado_dw.fact_ventas v
JOIN supermercado_dw.dim_cliente c USING(sk_cliente)
JOIN supermercado_dw.dim_canal ca USING(sk_canal)
JOIN supermercado_dw.dim_metodo_pago mp USING(sk_metodo_pago)
GROUP BY c.segmento,ca.nombre,mp.nombre;
-- 5. P3: comparar dias con y sin vigencia, incluidos dias sin ventas.
WITH dias AS (
 SELECT p.sk_producto,p.nombre,f.sk_fecha,
 EXISTS(SELECT 1 FROM supermercado.promocion pr
 WHERE f.fecha BETWEEN pr.fecha_inicio AND pr.fecha_fin AND
 ((pr.alcance='Producto' AND pr.id_producto_alcance=p.id_producto_origen) OR
 (pr.alcance='Categoria' AND pr.categoria_alcance=p.categoria))) AS con_promocion
 FROM supermercado_dw.dim_producto p CROSS JOIN supermercado_dw.dim_fecha f
), ventas AS (
 SELECT sk_producto,sk_fecha,SUM(monto_venta) AS importe
 FROM supermercado_dw.fact_ventas GROUP BY sk_producto,sk_fecha
)
SELECT d.nombre,d.con_promocion,COUNT(*) AS dias,
 SUM(COALESCE(v.importe,0)) AS ventas,
 SUM(COALESCE(v.importe,0))/COUNT(*) AS venta_diaria
FROM dias d LEFT JOIN ventas v USING(sk_producto,sk_fecha)
GROUP BY d.nombre,d.con_promocion ORDER BY d.nombre,d.con_promocion;
-- 6. Observaciones semanales: no son eventos diarios independientes.
SELECT COUNT(*) AS observaciones, SUM(flag_quiebre) AS sin_stock,
 SUM(flag_bajo_inventario) AS bajo_minimo FROM supermercado_dw.fact_inventario;
-- 7. Cobertura del ultimo corte: el umbral de 7 dias es una propuesta analitica.
WITH corte AS (SELECT MAX(sk_fecha) AS sk_fecha FROM supermercado_dw.fact_inventario)
SELECT p.nombre AS producto,s.nombre AS sucursal,i.stock_actual,i.unidades_vendidas_semana,
 7.0*i.stock_actual/NULLIF(i.unidades_vendidas_semana,0) AS cobertura_dias,
 CASE WHEN i.stock_actual=0 THEN 'Sin stock'
 WHEN i.unidades_vendidas_semana=0 THEN 'Sin ventas recientes'
 WHEN 7.0*i.stock_actual/i.unidades_vendidas_semana<7 THEN 'Cobertura menor a 7 dias'
 ELSE 'Cobertura de 7 dias o mas' END AS estado
FROM supermercado_dw.fact_inventario i JOIN corte USING(sk_fecha)
JOIN supermercado_dw.dim_producto p USING(sk_producto)
JOIN supermercado_dw.dim_sucursal s USING(sk_sucursal);
-- 8. Rotacion por producto/sucursal: misma ventana temporal que Power BI.
WITH inv AS (
 SELECT sk_producto,sk_sucursal,AVG(stock_actual::numeric) AS stock_promedio
 FROM supermercado_dw.fact_inventario GROUP BY sk_producto,sk_sucursal
), ventas AS (
 SELECT sk_producto,sk_sucursal,SUM(cantidad_vendida) AS unidades
 FROM supermercado_dw.fact_ventas GROUP BY sk_producto,sk_sucursal
)
SELECT p.nombre AS producto,s.nombre AS sucursal,i.stock_promedio,
 v.unidades/NULLIF(i.stock_promedio,0) AS rotacion
FROM inv i LEFT JOIN ventas v USING(sk_producto,sk_sucursal)
JOIN supermercado_dw.dim_producto p USING(sk_producto)
JOIN supermercado_dw.dim_sucursal s USING(sk_sucursal) ORDER BY rotacion DESC NULLS LAST;
