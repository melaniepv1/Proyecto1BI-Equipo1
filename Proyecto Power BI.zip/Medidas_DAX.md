# Medidas agregadas

## Clientes compradores
Tabla: `supermercado_dw fact_ventas`



```DAX
Clientes compradores =
DISTINCTCOUNT('supermercado_dw fact_ventas'[sk_cliente])
```

## Frecuencia de compra
Tabla: `supermercado_dw fact_ventas`

Tickets por cliente comprador dentro del periodo y filtros seleccionados.

```DAX
Frecuencia de compra =
DIVIDE([Cantidad de tickets], [Clientes compradores])
```

## Descuentos totales
Tabla: `supermercado_dw fact_ventas`



```DAX
Descuentos totales =
SUM('supermercado_dw fact_ventas'[monto_descuento])
```

## Ventas con promocion vigente
Tabla: `supermercado_dw fact_ventas`



```DAX
Ventas con promocion vigente =
CALCULATE([Ventas totales], 'supermercado_dw fact_ventas'[Periodo promocional] = "Con promocion vigente")
```

## Ventas sin promocion vigente
Tabla: `supermercado_dw fact_ventas`



```DAX
Ventas sin promocion vigente =
CALCULATE([Ventas totales], 'supermercado_dw fact_ventas'[Periodo promocional] = "Sin promocion vigente")
```

## Dias producto con promocion
Tabla: `supermercado_dw fact_ventas`



```DAX
Dias producto con promocion =
SUMX(VALUES('supermercado_dw dim_producto'[sk_producto]),
VAR Producto = CALCULATE(MAX('supermercado_dw dim_producto'[id_producto_origen]))
VAR Categoria = CALCULATE(SELECTEDVALUE('supermercado_dw dim_producto'[categoria]))
RETURN SUMX(VALUES('supermercado_dw dim_fecha'[fecha]),
VAR Dia = 'supermercado_dw dim_fecha'[fecha]
RETURN IF(COUNTROWS(FILTER(ALL('supermercado_dw dim_promocion'), 'supermercado_dw dim_promocion'[sk_promocion] > 0 &&
'supermercado_dw dim_promocion'[fecha_inicio] <= Dia && 'supermercado_dw dim_promocion'[fecha_fin] >= Dia &&
(('supermercado_dw dim_promocion'[alcance] = "Producto" && 'supermercado_dw dim_promocion'[id_producto_alcance] = Producto) ||
 ('supermercado_dw dim_promocion'[alcance] = "Categoria" && 'supermercado_dw dim_promocion'[categoria_alcance] = Categoria)))) > 0, 1, 0)))
```

## Dias producto sin promocion
Tabla: `supermercado_dw fact_ventas`



```DAX
Dias producto sin promocion =
COUNTROWS(VALUES('supermercado_dw dim_producto'[sk_producto])) * COUNTROWS(VALUES('supermercado_dw dim_fecha'[fecha])) - [Dias producto con promocion]
```

## Venta diaria con promocion
Tabla: `supermercado_dw fact_ventas`



```DAX
Venta diaria con promocion =
DIVIDE([Ventas con promocion vigente], [Dias producto con promocion])
```

## Venta diaria sin promocion
Tabla: `supermercado_dw fact_ventas`



```DAX
Venta diaria sin promocion =
DIVIDE([Ventas sin promocion vigente], [Dias producto sin promocion])
```

## Variacion diaria promocional
Tabla: `supermercado_dw fact_ventas`

Comparacion descriptiva por producto-dia; no demuestra causalidad.

```DAX
Variacion diaria promocional =
DIVIDE([Venta diaria con promocion] - [Venta diaria sin promocion], [Venta diaria sin promocion])
```

## Ultimo corte
Tabla: `supermercado_dw fact_inventario`



```DAX
Ultimo corte =
MAX('supermercado_dw fact_inventario'[sk_fecha])
```

## Stock ultimo corte
Tabla: `supermercado_dw fact_inventario`



```DAX
Stock ultimo corte =
VAR Corte = [Ultimo corte]
RETURN CALCULATE(SUM('supermercado_dw fact_inventario'[stock_actual]), KEEPFILTERS('supermercado_dw fact_inventario'[sk_fecha] = Corte))
```

## Minimo ultimo corte
Tabla: `supermercado_dw fact_inventario`



```DAX
Minimo ultimo corte =
VAR Corte = [Ultimo corte]
RETURN CALCULATE(SUM('supermercado_dw fact_inventario'[stock_minimo]), KEEPFILTERS('supermercado_dw fact_inventario'[sk_fecha] = Corte))
```

## Ventas semana ultimo corte
Tabla: `supermercado_dw fact_inventario`



```DAX
Ventas semana ultimo corte =
VAR Corte = [Ultimo corte]
RETURN CALCULATE(SUM('supermercado_dw fact_inventario'[unidades_vendidas_semana]), KEEPFILTERS('supermercado_dw fact_inventario'[sk_fecha] = Corte))
```

## Quiebres ultimo corte
Tabla: `supermercado_dw fact_inventario`



```DAX
Quiebres ultimo corte =
VAR Corte = [Ultimo corte]
RETURN CALCULATE(SUM('supermercado_dw fact_inventario'[flag_quiebre]), KEEPFILTERS('supermercado_dw fact_inventario'[sk_fecha] = Corte))
```

## Bajos ultimo corte
Tabla: `supermercado_dw fact_inventario`



```DAX
Bajos ultimo corte =
VAR Corte = [Ultimo corte]
RETURN CALCULATE(SUM('supermercado_dw fact_inventario'[flag_bajo_inventario]), KEEPFILTERS('supermercado_dw fact_inventario'[sk_fecha] = Corte))
```

## Stock promedio por corte
Tabla: `supermercado_dw fact_inventario`



```DAX
Stock promedio por corte =
AVERAGEX(VALUES('supermercado_dw fact_inventario'[sk_fecha]), CALCULATE(SUM('supermercado_dw fact_inventario'[stock_actual])))
```

## Rotacion del periodo
Tabla: `supermercado_dw fact_inventario`

Unidades vendidas del periodo divididas por stock total promedio de los cortes disponibles; no anualizada.

```DAX
Rotacion del periodo =
DIVIDE([Unidades vendidas], [Stock promedio por corte])
```

## Observaciones sin stock
Tabla: `supermercado_dw fact_inventario`



```DAX
Observaciones sin stock =
SUM('supermercado_dw fact_inventario'[flag_quiebre])
```

## Observaciones bajo minimo
Tabla: `supermercado_dw fact_inventario`



```DAX
Observaciones bajo minimo =
SUM('supermercado_dw fact_inventario'[flag_bajo_inventario])
```

## Cobertura dias
Tabla: `supermercado_dw fact_inventario`

Solo producto-sucursal; sin ventas semanales queda en blanco. Utiliza la demanda de los 7 dias hasta el corte.

```DAX
Cobertura dias =
IF(HASONEVALUE('supermercado_dw dim_producto'[sk_producto]) && HASONEVALUE('supermercado_dw dim_sucursal'[sk_sucursal]),
DIVIDE([Stock ultimo corte], DIVIDE([Ventas semana ultimo corte], 7)))
```

## Estado cobertura
Tabla: `supermercado_dw fact_inventario`



```DAX
Estado cobertura =
IF(NOT(HASONEVALUE('supermercado_dw dim_producto'[sk_producto]) && HASONEVALUE('supermercado_dw dim_sucursal'[sk_sucursal])), BLANK(),
IF(ISBLANK([Ultimo corte]), BLANK(),
SWITCH(TRUE(), [Stock ultimo corte] = 0, "Sin stock", [Ventas semana ultimo corte] = 0, "Sin ventas recientes", [Cobertura dias] < 7, "Cobertura menor a 7 dias", "Cobertura de 7 dias o mas")))
```

## Pares en riesgo
Tabla: `supermercado_dw fact_inventario`



```DAX
Pares en riesgo =
VAR Corte = [Ultimo corte]
RETURN COUNTROWS(FILTER('supermercado_dw fact_inventario', 'supermercado_dw fact_inventario'[sk_fecha] = Corte &&
('supermercado_dw fact_inventario'[stock_actual] = 0 || ('supermercado_dw fact_inventario'[unidades_vendidas_semana] > 0 &&
DIVIDE(7 * 'supermercado_dw fact_inventario'[stock_actual], 'supermercado_dw fact_inventario'[unidades_vendidas_semana]) < 7))))
```

## Pares evaluados
Tabla: `supermercado_dw fact_inventario`



```DAX
Pares evaluados =
VAR Corte = [Ultimo corte]
RETURN CALCULATE(COUNTROWS('supermercado_dw fact_inventario'), KEEPFILTERS('supermercado_dw fact_inventario'[sk_fecha] = Corte))
```

## Porcentaje pares en riesgo
Tabla: `supermercado_dw fact_inventario`



```DAX
Porcentaje pares en riesgo =
DIVIDE([Pares en riesgo], [Pares evaluados])
```